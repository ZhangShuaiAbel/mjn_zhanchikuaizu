<template>
    <div class="weixin">
       <img src="../../assets/images/banner.png" alt="" style="width:100%">
    </div>
</template>



<style lang="less" src="./index.less"></style>