<template>
    <div class="msgsuccess">
        <div class="msg-bgk"></div>
        <div class="msg-prompt">我们已收到您的信息<br>请等待我们的业务人员与您联系</div>
        <div class="btn" @click="serviceFun">返回</div>
    </div>
</template>

<script>
import {bus, busType} from '@/bus';

export default {
    name: 'paysuccess',
    methods: {
        serviceFun(){
            let action = `zclease://app?action=2`;
            bus.$emit(busType.IFRAME, action);
        }
    }
}
</script>

<style lang="less" src="./index.less"></style>