<template>
    <div class="enclosure">
        <div class="img" v-if="agreement.length > 0">
            <div class="img_main"  :style="{background: 'url('+agreement[num].url+')' + 'no-repeat center center' , backgroundSize: '100%'}"></div> 
　　　　 </div>
    </div>
</template>

<script>
import {bus, busType} from '@/bus';
import * as connectURL from "@/http/common/connectURL";

export default {
    data(){
        return {
            agreement:[],
            num:'',
        }   
    },
    beforeRouteEnter: (to, from, next) => {
            // 初始化数据
            next(vm => {vm.getInitData()});
        },
   methods: {
        // 获取初始化数据
        getInitData() {
            // 初始化请求
            this.$http(connectURL.INITAGREEMENT,{
                type: 'GET',
                params: {
                    orderId: this.$route.query.orderId
                }
            })
            .then(res => {
                if ( res.data.code != 0 ) {
                   this.$toast.show(res.data.message);
                   return;
               }
                // 列表是否为空
                this.agreement=res.data.data;
                this.num=this.$route.query.num
                console.log('12312312',res, this.num)
            })
            .catch(err => {
                this.$toast.show(err.message);
            })
        },


   }
}
</script>

<style lang="less" src="./index.less"></style>