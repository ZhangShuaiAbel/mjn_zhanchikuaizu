<template>
    <div class="enclosure">
        <div class="enclosure_main" v-if="showData">
            <div class="enclosure_list"  @click="clickImg(index)" 
                v-for="(item, index) in agreement" 
                :key="index" 
                :style="{ background: 'url(' + item.url + ')' + 'no-repeat center center', backgroundSize:'100%' }"
            >
            </div>
            <div class="img" v-if="showImg" @click="showimg">
                <div class="img_main"  :style="{background: 'url('+agreement[num].url+')' + 'no-repeat center'}"></div> 
    　　　　 </div>
        </div>
　　　　
        <div class="enclosure_img"  v-if="showData1">
                <div></div>
                <p>该订单还未上传协议附件<br>请耐心等待业务人员签约并上传附件</p>
        </div>
    </div>
</template>

<script>
import {bus, busType} from '@/bus';
import * as connectURL from "@/http/common/connectURL";

export default {
    data(){
        return {
            showImg:false,
            showData:true,
            showData1:true,
            agreement:[],
            num:'',
        }   
    },
    beforeRouteEnter: (to, from, next) => {
            // 初始化数据
            next(vm => {vm.getInitData()});
        },
   methods: {
        clickImg(e) {
            this.showImg =  true;
            this.num = e;
            this.$router.push({ path: "/enclosureDetails?orderId="+this.$route.query.orderId+"&num="+this.num});
        },
        showimg() {
            this.showImg =  false;
        },
        

        // 获取初始化数据
        getInitData() {
            // 初始化请求
            this.$http(connectURL.INITAGREEMENT,{
                type: 'GET',
                params: {
                    orderId: this.$route.query.orderId
                }
            })
            .then(res => {
                // 失败
               if ( res.data.code != 0 ) {
                   this.$toast.show(res.data.message);
                   return;
               }
                // 列表是否为空
                this.agreement=res.data.data;
                if( res.data.data.length <= 0) {
                    this.showData1 = true;
                    this.showData = false;
                }else{
                    this.showData = true;
                    this.showData1 = false;
                } 
            })
            .catch(err => {
                this.$toast.show(err.message);
            })
        },


   }
}
</script>

<style lang="less" src="./index.less"></style>