<template>
    <div class="real">
        <div class="real-header">
            <div class="icon"></div>
            <div class="font">初次使用线上支付请进行实名认证</div>
        </div>
        <div class="box"></div>
        <div class="form">
            <div class="form-input">
                <span>真实姓名:</span>
                <input type="text" v-model="name" placeholder="请输入姓名">
            </div>
            <div class="form-input">
                <span>身份证号:</span>
                <input type="text" v-model="idCard" placeholder="请输入身份证号码">
            </div>
        </div>
        <div class="font-msg">仅用于在线支付认证，展翅快租不会向任何人泄露您的个人信息</div>
        <div class="btn" @click="addSaleFun">认证</div>
    </div>
</template>

<script>
import {bus, busType} from '@/bus';
import * as connectURL from "@/http/common/connectURL";

export default {
    name: 'realNameAuthentication',
    data() {
        return {
            name:"",        
            idCard:"",       
        }
    },
    mounted() {

    },
    methods: {
        addSaleFun(){
            if(this.name == ""){
                this.$toast.show("真实姓名不能为空");  
            }else if(this.idCard == ""){
                this.$toast.show("身份证号码不能为空");
            }else if(!(/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/.test(this.idCard))){
                this.$toast.show("身份证号码格式有误");
            }else{
                this.$http(connectURL.REALNAME,{
                    type: 'GET',
                    params:{
                        userId : this.$route.query.userId,
                        name : this.name,
                        idCard : this.idCard
                    }
                })
                .then(res => {
                    //失败
                    console.log( res );
                    if ( res.data.code != 0 ) {
                        this.$toast.show(res.data.message);  
                        return;
                    }
                    if(this.$route.query.type == 1){
                        this.$router.push(`/realNamesuccess?userId=${this.$route.query.userId}&orderId=${this.$route.query.orderId}&type=${this.$route.query.type}`);
                    }else if(this.$route.query.type == 2){
                        this.$router.push(`/realNamesuccess?userId=${this.$route.query.userId}&billId=${this.$route.query.billId}&type=${this.$route.query.type}`);
                    }
                })
                .catch(err => {
                    console.log( err )
                    this.$toast.show(err.message);
                });
            }
        }
    }
}
</script>

<style lang="less" src="./index.less"></style>