<template>
    <div class="add_authentication">
        <div class="add_authentication_content">
            
            <!-- 循环主体 -->
            <ul class="add_authentication_list">
                <li 
                    class="add_authentication_item" 
                    v-for="(item, index) in list" 
                    :key="index" 
                    @click="handleAuthentication(item.key, item.stateText)" 
                    v-show="isShowMast(item.haveHide)"
                >
                    <span 
                        :class="item.key === 'title' ? 'add_authentication_item_title' : ''"
                    >{{item.name}}</span>
                    <span 
                        :class="item.stateText === '已上传' ? 'add_authentication_item_title_istrue' : ''" 
                        v-show="item.key != 'title'"
                    >{{item.stateText}}</span>
                </li>
            </ul>

            <!-- 按钮 -->
            <div class="add_authentication_button" @click="next">提交</div>
        </div>
    </div>
</template>

<script>
/**
 * '认证类型 
 * 1：加公执照图片 
 * 2：法人身份证 
 * 3：员工社保缴存记录 
 * 4：银行流水明细 
 * 5：财务报表 
 * 6：融资到账证明 
 * 7：高新技术企业认证 
 * 8：专利认证 
 * 9：合同认证 
 * 10：企业纳税证明 
 * 11：企业芝麻信用
 * 12: 办公场所租赁合同
*/
import {bus, busType} from '@/bus';
import * as connectURL from "@/http/common/connectURL";

export default {
   name: 'addAuthentication',
   data() {
       return {
           initData: [],
           list: [
               {
                   name: '必填附件',
                   key: 'title',
                   haveHide: true
               },
               {
                   name: '加公章执照图片',
                   key: '1',
                   state: null,
                   stateText: '',
                   haveHide: true
               },
               {
                   name: '法人身份证正反面',
                   key: '2',
                   state: null,
                   stateText: '',
                   haveHide: true
               },
               {
                   name: '办公场所租赁合同',
                   key: '12',
                   state: null,
                   stateText: '',
                   haveHide: true
               },
               {
                   name: '选填附件',
                   key: 'title',
                   haveHide: false
               },
               {
                   name: '财务报表',
                   key: '5',
                   state: null,
                   stateText: '',
                   haveHide: false
               },
               {
                   name: '银行流水明细',
                   key: '4',
                   state: null,
                   stateText: '',
                   haveHide: false
               },
               {
                   name: '融资到账证明',
                   key: '6',
                   state: null,
                   stateText: '',
                   haveHide: false
               },
               {
                   name: '员工社保缴存记录',
                   key: '3',
                   state: null,
                   stateText: '',
                   haveHide: false
               },
               {
                   name: '专利认证',
                   key: '8',
                   state: null,
                   stateText: '',
                   haveHide: false
               },
               {
                   name: '合同认证',
                   key: '9',
                   state: null,
                   stateText: '',
                   haveHide: false
               },
               {
                   name: '高新技术企业认证',
                   key: '7',
                   state: null,
                   stateText: '',
                   haveHide: false
               },
               {
                   name: '企业纳税证明',
                   key: '10',
                   state: null,
                   stateText: '',
                   haveHide: false
               },
            //    {
            //        name: '企业芝麻信用',
            //        key: '11',
            //        state: null,
            //        stateText: '',
            //        haveHide: false
            //    }
           ]
       }
   },
   beforeRouteEnter: (to, from, next) => {
       // 初始化数据
       next(vm => {vm.gitInitData()})
   },
   methods: {
       // 是否显示必要附件
       isShowMast(haveHide) {
           if( haveHide && this.$route.query.state == 2 ) {
               return false;
           }else {
               return true;
           }
       },
       // 获取初始化数据
       gitInitData() {
           this.$http(connectURL.INITADD,{
               type: 'GET',
               params: {
                   companyId: this.$route.query.id
               }
           })
           .then(res => {
               // 失败
               if ( res.data.code != 0 ) {
                   this.$toast.show(res.data.message);
                   return;
               }
               
               // 返回数据并设置到状态
               let initData = res.data.data;
               this.initData = initData;

               console.log( this.initData )
               // 如果返回 [] 全部未认证
               if ( initData.length === 0 ) {
                   this.list.forEach((item, index) => {
                       item.stateText = '未上传';
                   })
                   return;
               }else { // 如果返回非 [] 返回数据为已认证
                   this.list.forEach((item, index) => {
                       item.stateText = '未上传';
                   })

                    this.list.forEach((item, index) => {
                        if ( item.key === 'title' ) return false; 
                        initData.forEach((subItem, subIndex) => {
                            if( item.key === subItem.type ) {
                                item.stateText = '已上传';
                            }
                        })
                    })
               }
               console.log( res )
           })
           .catch(err => {
               console.log( err.message )
               this.$toast.show(err.message);
           })
       },
       // 触发认证 - native 交互
       handleAuthentication(key, state) {
           if ( (key == 1 && state === '已上传') || (key == 2 && state === '已上传') ) {
               return;
           }
           let action = `zclease://app?action=1&data={"type": ${key}, "companyId": ${this.$route.query.id}}`;
           bus.$emit(busType.IFRAME, action);
       },
       // 通过校验后更新state
       updateState() {
           let params = {
               id: parseInt(this.$route.query.id),
               state: 1
           }
           // 更新接口
           this.$http(connectURL.UPDATEMAST,{
               type: 'POST',
               params
           })
           .then(res => {
               // 失败
               if( res.data.code != 0 ) {
                   this.$toast.show(res.data.message);
                   return;
               }

               this.$router.push(`/successauthentication?userId=${this.$route.query.userId}&id=${this.$route.query.id}`);
           })
           .catch(err => {
               console.log( err )
               this.$toast.show(err.message);
           })
       },
       // 继续
       next() {
           // 所有信息都未认证
           if( this.initData.length === 0 ) {
               this.$toast.show('请认证必要附件');
               return;
           }
           // 提取是否认证必要附件
           let arr = []; 
           this.initData.forEach((item,index) => {
               arr.push(item.type + '');
           })
           
            // 已认证必填附件
            if ( arr.indexOf('1') != -1 && arr.indexOf('2') != -1 && arr.indexOf('12') != -1 ) { 
                // 更新状态
                this.updateState();
            }else { 
                this.$toast.show('请认证必要附件');
            }
       }
   }
}
</script>

<style lang="less" src="./index.less"></style>