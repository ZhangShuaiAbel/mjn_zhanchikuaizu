<template>
    <div class="saleAfter" ref="wrapper">
          <div class="saleAfter_header">
              <h3><span></span>展翅快组退换机流程</h3>
              <div class="saleAfter_main">
                  <div  v-for="(subItme, index) in items" :class="subItme.class" :key="index" @click="isShow(subItme, index)">
                    <span :class="subItme.show ? 'active' : ''"></span> 
                  </div>

                  
              </div>
          </div>
            
         
            <!-- scroll start -->
            <div class="scroll_wrap" ref="scroll">
                  <div  v-for="(items, index) in itemsTetx"  :key="index" :class="items.show ? 'scroll_mian transform' : 'scroll_mian'" >
                      <h3><span></span>{{items.title}}</h3>
                      <div class="saleAfter_tetx_main" v-html="items.content">

                      </div>
                  </div>
            </div>
            <!-- scroll end -->
    </div>
</template>
<style>
table{
  border: 1px solid #333;
  border-bottom:none;
  border-right: none;
  margin-top:20px;
  width: 100%;
}
table tr td{
  width: 50%;
  border-bottom: 1px solid #333;
  border-right: 1px solid #333;
  text-align: center;
}
 p{
    font-size: 28px;
    color: #333;
    margin-top:20px;
    line-height: 40px;
  }
</style>

<script>
export default {
  name: "help",
  data() {
    return {
      items: [
        { class: "saleAfter_1", show: true },
        { class: "saleAfter_2", show: false },
        { class: "saleAfter_3", show: false },
        { class: "saleAfter_4", show: false },
        { class: "saleAfter_5", show: false },
        { class: "saleAfter_6", show: false }
      ],
      itemsTetx: [
        { 
          title:'联系客服',
          content:
            "如您需要退换机或设备维修，请拨打客服热线：400-181-0161，详细说明需退换机的设备型号及退换原因，并留下联系方式，以便售后人员与您取得联系。",
          show: true
        },
        {
          title:'售后回访',
          content:
            "<p>我们的售后人员将在1-2个工作日内与您取得联系。</p><p>展翅技术人员会根据您遇到的问题确认是否需要更换机器，如不用更换技术员会指导当场处理；如需更换则进行下一环节；</p>",
          show: false
        },
        {
          title:'打包发货',
          content:
            "<p>配送地址：北京海淀区彩和坊路华一控股大厦3层</p><p>联系人：熊先生</p><p>联系电话：13297573232</p><p>请使用顺丰寄出需退换的设备，若选择其他快递需您自理运费</p><p>请在包装箱内放置A4纸，写明如下信息：<br>1）退换机型号与台数<br>2）租赁公司名称<br>3）收件联系人姓名&电话<br>4）换机原因（如有故障，请写故障描述）</p><table><tr><td>事因</td><td>运费及保价费</td><tr><tr><td>因自然故障退换机</td><td>展翅快租</td><tr><tr><td>到期退租</td><td>展翅快租</td><tr><tr><td>人为故障换机（往返）</td><td>客户</td><tr><tr><td>未到期非故障换机（往返）</td><td>客户</td><tr></table><p>客户寄回的设备应进行保价，保价金额应为押金金额由客户承担运费和保价费的情形，应由客户在寄出时支付运费与保价费。</p><p>由展翅快租承担运费和保价费的情形，客户在寄出时可直接选择到付。</p>",
          show: false
        },
        {
          title:'展翅收货',
          content:'<p>如设备在快递过程中出现问题，处理方式如下：</p><p>根据快递公司规定，运输过程中的损坏应由寄件方索赔；<br>1）客户委托顺丰快递运输的设备发生物流损坏后展翅快租首先尝试代理索赔，如顺丰不同意代理索赔的情况，展翅快租协助客户进行索赔；<br>2）客户委托其它快递或物流运输公司运输的设备发生物流损坏的由客户自主索赔，展翅快租提供照片、鉴定报告等证据协助处理；</p>',
          show: false
        },
        { title:'设备检修',
          content: "<p>展翅快租对设备进行更换。</p><p>如您没有特殊要求，将更换为同样型号设备发出，发货时我们将以短信的形式通知您快递单号。</p><p>如您申请退机将跳过此流程。</p>", 
          show: false 
        },
        { title:'更新账单',
          content: "<p>我们将根据您退换机的具体情况，调整每月生成账单的费用。</p><p>已经生成的历史账单，不进行调整。</p>", 
          show: false
        }
      ],
      isShowimg: false
    };
  },
  methods: {
    isShow(subItme, index) {
      subItme.show = true;

      this.items.forEach(function(item, indexShow) {
        if (indexShow != index) {
          item.show = false;
        }
      });
      this.itemsTetx.forEach(function(item, indexShow) {
        item.show = true;
        if (indexShow != index) {
          item.show = false;
        }
      });
    }
  }

  // watch: {
  //     isShowRegulation(to) {
  //         document.addEventListener('touchmove',(ev) => {
  //             if ( to ) {
  //                 ev.preventDefault();
  //             }else {
  //                 ev.returnValue = true;
  //             }
  //         })
  //     }
  // }
};
</script>


<style lang="less" src="./index.less" scoped></style>
