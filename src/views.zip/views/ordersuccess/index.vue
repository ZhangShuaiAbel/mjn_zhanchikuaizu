<template>
    <div class="ordersuccess">
        <div class="ordersuccess-bgk"></div>
        <div class="ordersuccess-font">提交成功</div>
        <div class="ordersuccess-prompt">您已成功提交订单，我们的业务人员将于24小时内与您取得联系，完成后续流程。</div>
        <div class="ordersuccess-two"></div>
        <div class="btn" @click="serviceFun">返回首页</div>
    </div>
</template>

<script>
import {bus, busType} from '@/bus';

export default {
    name: 'paysuccess',
    methods: {
        serviceFun(){
            let action = `zclease://app?action=5`;
            bus.$emit(busType.IFRAME, action);
        }
    }
}
</script>

<style lang="less" src="./index.less"></style>