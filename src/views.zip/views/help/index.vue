<template>
    <div class="help">
      <div class="scroll_wrap">
        <div class="help_container">
            <div class="head">
                <div class="head_list">
                    <a href="javascript:;" @click="openIphone">
                        <span></span>
                        <p>客服电话</p>
                    </a>                  
                </div>
                 <div class="head_list">
                    <a href="javascript:;" @click="serviceFun">
                        <span></span>
                        <p>在线客服</p>
                    </a>
                </div>
                <p class="border"></p>
            </div>

            <div class="help_content" ref="title" v-for="(item, index) in staticData" :key="index">
                <p class="help_content_title">
                    <span></span>
                    <span v-text="item.title"></span>
                </p>
                <ul class="help_content_ul">
                    <li class="help_content_li"  v-for="(subItme, subIndex) in item.items" :key="subIndex">
                        <p 
                            class="help_content_li_title" 
                            :class="subItme.isShow ? 'help_content_li_title_active' : ''" 
                            v-text="subItme.title" 
                            @click="isShowContent(index,subIndex)"
                        ></p>
                        <div 
                            class="help_content_content"
                            v-text="subItme.content"
                            :style="!subItme.isShow ? {height: subItme.height} : {height: '0px'}"
                            ref="content"
                        ></div>
                    </li>
                </ul>
            </div>
        </div>
      </div>
      <mc-dialog :isShow="isShow" @close=" isHide => isShow = isHide">
            <div class="iphone">
                <div class="iphone-num">400-181-0161</div>
                <div class="iphone-btn">
                    <div class="qu" @click="closeFun">取消</div>
                    <a class="da" href="tel:4001-810-161">拨打</a>
                </div>
            </div>
        </mc-dialog>
    </div>
</template>

<script>
const staticData = [
    {
        title: '账号与免押认证相关问题',
        items: [
            {
                title: '1.个人账号与企业账号有什么区别？',
                content: '个人租用需要交纳设备保值押金，公司租用可根据提供的信审资料申请一定额度的免押金租赁业务。',
                isShow: false,
                height: ''
            },
            {
                title: '2.我可以同时注册企业账号与个人账号么？',
                content: '同一个手机号仅能注册一个账号。请在注册时根据自身实际情况进行注册。',
                isShow: false,
                height: ''
            },
            {
                title: '3.免押金额度是什么？',
                content: '展翅快租将为您授予一定的“免押金额度”，若您所租赁设备的总押金价值在免押金额度之内且符合相关要求，您将无需为此电脑支付押金，从而帮助您的企业降低资金成本，释放流动性。免押金额度将与您所在企业的资质有关，目前仅支持企业申请免押金额度。您可进入“个人中心->免押金额度"页面申请或查看您当前的免押金额度。展翅快租欢迎您提供更多真实信息以获得更高的免押金额度。若您希望进一步了解并提高免押金额度，请致电400-181-0161。',
                isShow: false,
                height: ''
            },
            {
                title: '4.免押金材料如何提交？',
                content: '当前仅有企业用户可以提交免押金认证材料，请登录后前往个人中心进行提交。必要认证信息为申请减押金时必须的材料，一但获取额度，不能再进行更改。增额授信信息可以随时进行调整与提交，补充越完善，获取的额度越高。',
                isShow: false,
                height: ''
            },
            {
                title: '5.免押金额度如何使用？',
                content: '当企业用户下单时，免押额度将自动从押金中扣除，使用免押额度不能超过押金总额。',
                isShow: false,
                height: ''
            },
            {
                title: '6.免押额度有有效期么？',
                content: '免押额度不设置有效期，下单时自动使用。',
                isShow: false,
                height: ''
            },
            {
                title: '7.提交授信材料时，我应该注意什么?',
                content: '为保护您的资料安全，您在提供证件资料时，请加上一行“仅供租赁展翅快租设备使用，其他用途无效”，且此句覆盖于您的资料内容上。',
                isShow: false,
                height: ''
            }
        ]
    },
    {
        title: '租赁相关问题',
        items: [
            {
                title: '1.展翅快租租赁的流程是怎么样的？',
                content: '①用户选择设备下单②销售人员与您取得联系并签约③合同合规审核④支付首期租金⑤仓库工作人员发货。⑥确认收货，开始租赁。',
                isShow: false,
                height: ''
            },
            {
                title: '2.展翅快租如何计算起租费用？',
                content: '①起租费用为开始租赁前需提前支付的费用。②展翅快租每月10日自动生成当月账单。③起租日默认为下单日起第5天。④展翅快租起租费用计算方式如下：I.起租日距下个账单日≥15天时，起租费用包含零散租金、保修费用、押金、押金减免。首个账单日正常支付首月租金。II.起租日距下个账单日＜15天时，起租费用包含零散租金、首月租金、保修费用、押金、押金减免。首个账单日无需支付租金。',
                isShow: false,
                height: ''
            },
            {
                title: '3.起租费用需在多长时间内支付？',
                content: '起租费用请在签约后5日内支付，超过该时限我们将关闭您的订单，并释放您订单占用的库存。您需要重新下单。',
                isShow: false,
                height: ''
            },
            {
                title: '4.我能够选择产品、型号及数量么？',
                content: '您可以任意选择您想要租赁的产品及型号。可下单数量不能超过当前可用库存。如当前库存设备不能满足您的需求，请拨打客服电话或联系您的销售反馈给我们。',
                isShow: false,
                height: ''
            }
        ]
    },
    {
        title: '账单相关问题',
        items: [
            {
                title: '1.账单生成日？',
                content: '展翅快租每月10日生成租金账单。',
                isShow: false,
                height: ''
            },
            {
                title: '2.账单支付日？',
                content: '每月20日为账单的最后支付日。若您未在20日前支付，将每天产生1‰的滞纳金，请您提前支付账单，避免产生逾期费用。',
                isShow: false,
                height: ''
            },
            {
                title: '3.账单费用组成？',
                content: '账单费用为您租赁订单的租金费用+保险费用+滞纳金（逾期产生）。若您对账单金额存在疑问，请联系客服。',
                isShow: false,
                height: ''
            },
            {
                title: '4.我可以通过线下打款的方式支付订单么？',
                content: '如您需要线下支付定单，请您将打款凭证提供给我们的业务人员。我们审核通过后，将为您更新订单支付状态。',
                isShow: false,
                height: ''
            }
        ]
    },
    {
        title: '物流相关问题',
        items: [
            {
                title: '1.签约后几天能安排送发货？',
                content: '如无特殊情况，签约次日即可安排发货。',
                isShow: false,
                height: ''
            },
            {
                title: '2.发货使用哪种快递？如何查询物流情况？',
                content: '如无特殊情况，展翅快租采用顺丰快递。您可以通过订单详情查看快递单号，并通过顺丰官网查询物流情况。工作人员发货时，我们也会短信通知您。',
                isShow: false,
                height: ''
            },
            {
                title: '3.我可以变更收货人及收货地址么？',
                content: '发货前您可以拨打客服电话与我们取得联系。如已经发货，您可以与承运的快递公司联系，改变配送信息。',
                isShow: false,
                height: ''
            },
            {
                title: '4.快递的运费由谁承担？',
                content: '①展翅快租将通过顺丰快运将客户所订机器快递上门（免运费）。②机器租用过程中，若是正常硬件故障或正常租期结束导致的机器退回，均由展翅快租承担运费，客户通过顺丰快运将机器发至展翅快租即可。（到付需保价，若未保价造成的机器损坏由客户承担）③机器租用过程中，若是由客户人为故障或提前退租导致的机器退回，应由客户承担运费。',
                isShow: false,
                height: ''
            },
            {
                title: '5.收到的设备存在问题怎么办？',
                content: '如您发现收到的设备存在问题，请拒收设备并及时与我们取得联系，协商解决方案。',
                isShow: false,
                height: ''
            },
        ]
    },
    {
        title: '售后服务相关问题',
        items: [
            {
                title: '1.售后服务相关问题',
                content: '①客户有电脑需要报修的，应当拨打全国服务热线400-181-0161联系售后服务。②保修服务范围根据您是否购买意外保修决定。',
                isShow: false,
                height: ''
            },
            {
                title: '2.丢失机器怎么办？',
                content: '若客户不慎将机器丢失，需按官网保值价赔偿。',
                isShow: false,
                height: ''
            },
            {
                title: '3.设备在使用过程中出现故障，多久能得到处理？',
                content: '在设有分公司的城市8个工作小时内上门维修并处理完成；在无分公司的城市，若可以远程协助解决的展翅快租将派人远程协助解决，若无法远程协助解决则可将整机快递给展翅快租进行维护。',
                isShow: false,
                height: ''
            },
            {
                title: '4.我能否提前还机？',
                content: '如您需要提前还机，需要支付剩余应付租金的50%的额外费用。',
                isShow: false,
                height: ''
            },
            {
                title: '5.还机时的配送地址与联系人？',
                content: '还机地址：北京海淀区彩和坊路华一控股大厦3层  联系人：熊先生  联系电话：13297573232（仅限快递拨打）',
                isShow: false,
                height: ''
            },
        ]
    }
]

import {bus, busType} from '@/bus';
import * as connectURL from "@/http/common/connectURL";

export default {
    name: 'help',
    data() {
        return {
            isShowToast: false,
            isShowRegulation:false,
            staticData,
            isShow:false,
            isHide:false,
        };
    },
    mounted() {
        let _this = this;
        this.$nextTick(() => {
            console.log( _this.$refs.content[0].offsetHeight )

            let arr = [];
            let copyStaticData = _this.staticData;

            for( let i =0; i<_this.$refs.content.length; i++ ) {
                arr.push(_this.$refs.content[i].offsetHeight + 'px');
            }

            console.log( arr )

            for( let i=0; i<_this.staticData.length; i++ ) {
                for(let j=0; j<_this.staticData[i].items.length; j++) {
                    copyStaticData[i].items[j].height = arr[0];
                    copyStaticData[i].items[j].isShow = !copyStaticData[i].items[j].isShow;
                    arr.splice(0,1);
                }
            }

            _this.staticData = [];
            _this.staticData = copyStaticData;

           console.log( copyStaticData )
            

            // for( let i=0; i<_this.$refs.title.length; i++ ) {
            //     for ( let j=0; j<_this.$refs.content.length; j++ ) {
            //         console.log( _this.$refs.content[i].offsetHeight )
            //         _this.staticData[i].items[j].height = _this.$refs.title
            //     }
            // }

            

        })
        
    },
    methods: {
        openIphone(){
            this.isShow = true;
        },
        closeFun(){
            this.isShow = false;
        },
        isShowContent(index, subIndex) {
            this.staticData[index].items[subIndex].isShow = !this.staticData[index].items[subIndex].isShow;
        },
        serviceFun(){
            let action = `zclease://app?action=4`;
            bus.$emit(busType.IFRAME, action);
        }
    },

    watch: { 
        isShowRegulation(to) {
            document.addEventListener('touchmove',(ev) => {
                if ( to ) {
                    ev.preventDefault();    
                }else {
                    ev.returnValue = true; 
                }
            })
        }
    }
}
</script>

<style lang="less" src="./index.less"></style>
