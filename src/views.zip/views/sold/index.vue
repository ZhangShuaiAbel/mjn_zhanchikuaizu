<template>
    <div class="sold">
        <div class="form">
            <div class="form-input">
                <span>请输入姓名：</span>
                <input type="text" v-model="name">
            </div>
            <div class="form-input">
                <span>请输入联系方式：</span>
                <input type="text" v-model="phone">
            </div>
            <textarea placeholder="请描述你要出售的设备" v-model="description"></textarea>            
        </div>
        <div class="btn" @click="addSaleFun">提交</div>
    </div>
</template>

<script>
import {bus, busType} from '@/bus';
import * as connectURL from "@/http/common/connectURL";
export default {
    name: 'sold',
    data() {
        return {
            name:"",        
            phone:"",        
            description:"",        
        }
    },
    mounted() {

    },
    methods: {
        addSaleFun(){
            if(this.name == ""){
                this.$toast.show("姓名不能为空");  
            }else if(this.phone == ""){
                this.$toast.show("手机号码不能为空");
            }else if(!(/^1(3|4|5|6|7|8)\d{9}$/.test(this.phone))){
                this.$toast.show("手机号码格式有误");
            }else if(this.description == ""){
                this.$toast.show("描述不能为空");
            }else{
                this.$http(connectURL.ADDUSERSALE,{
                    type: 'POST',
                    params:{
                        userId : this.$route.query.userId,
                        name : this.name,
                        phone : this.phone,
                        saleItem : this.description,
                    }
                })
                .then(res => {
                    // 失败
                    if ( res.data.code != 0 ) {
                        this.$toast.show(res.data.message);  
                        return;
                    }
                    this.$router.push(`/msgsuccess`);
                })
                .catch(err => {
                    console.log( err )
                    this.$toast.show(err.message);
                });
            }
        }
    }
}
</script>

<style lang="less" src="./index.less"></style>