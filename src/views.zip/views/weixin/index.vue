<template>
    <div class="weixin">
       <img src="../../assets/images/weixin.png" alt="">
    </div>
</template>



<style lang="less" src="./index.less"></style>