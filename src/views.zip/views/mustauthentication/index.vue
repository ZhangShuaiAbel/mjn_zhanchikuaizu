<template>
    <div class="must_authentication" style="overflow-y: scroll;">
        <div class="must_authentication_top" v-show="$route.query.isShow ? false : true">
            <span class="must_authentication_top_icon"></span>
            <span class="must_authentication_top_text">该页面信息一但获取额度，无法再次修改。经办人不是法人时需填写完整经办人信息。</span>
        </div>

        <ul class="must_authentication_list">
            <li class="must_authentication_item" v-for="(item, index) in list" :key="index">
                <span :class="item.value ? 'must_authentication_name' : 'must_authentication_name_active'">{{item.name}}</span>
                <input v-show="!item.isShow" class="must_authentication_input" v-model="item.value" type="text">
                <span v-show="item.isShow" class="must_authentication_bench" v-text="item.value"></span>
                <div v-show="item.isPrompt" class="must_authentication_item_prompt"></div>
            </li>
            
            <li class="must_authentication_item_add" v-show="$route.query.isShow ? true : false" @click="handleShow('1')">
                <span class="must_authentication_name">加公章执照照片</span>
                <span class="must_authentication_bench">已上传</span>
            </li>
            <li class="must_authentication_item_add" v-show="$route.query.isShow ? true : false" @click="handleShow('2')">
                <span class="must_authentication_name">法人身份证正反面</span>
                <span class="must_authentication_bench">已上传</span>
            </li>
            <li class="must_authentication_item_add" v-show="$route.query.isShow ? true : false" @click="handleShow('12')">
                <span class="must_authentication_name">办公场所租赁合同</span>
                <span class="must_authentication_bench">已上传</span>
            </li>
        </ul>

        <div class="must_authentication_next" @click="next" v-show="$route.query.isShow ? false : true">继续</div>

        <mc-dialog :isShow="isShowDialog">
            <div class="dialog_contents">
                <p class="dialog_contents_title">
                    <span class="dialog_contents_title_icon"></span>
                    <span class="dialog_contents_title_text">温馨提示</span>
                </p>
                <p class="dialog_contents_content">填写的信息与工商登记信息不一致或不存在，请核对您的企业信息。</p>
                <p class="dialog_contents_btn" @click="closeDialog">
                    <span>确认</span>
                </p>
            </div>
        </mc-dialog>
    </div>
</template>

<script>
console.log('test' )
import {bus, busType} from '@/bus';
import * as connectURL from "@/http/common/connectURL";

export default {
    name: 'mustAuthentication',
    data() {
        return {
            isNewOrder: null, // 是否为新创建认证
            isShowDialog: false,
            list: [  // 列表数据
                {
                    name: '公司名称:',
                    key: 'name',
                    value: null,
                    isShow: null,
                    isPrompt: false
                },
                {
                    name: '执照号码:',
                    key: 'license',
                    value: null,
                    isShow: null,
                    isPrompt: false
                },
                {
                    name: '公司地址:',
                    key: 'address',
                    value: null,
                    isShow: null
                },
                {
                    name: '公司网站(选填):',
                    key: 'web',
                    value: '',
                    isShow: null
                },
                {
                    name: '法人姓名:',
                    key: 'holderName',
                    value: null,
                    isShow: null,
                    isPrompt: false
                },
                {
                    name: '法人身份证号:',
                    key: 'holderIdcard',
                    value: null,
                    isShow: null,
                    isPrompt: false
                },
                {
                    name: '法人手机号:',
                    key: 'holderPhone',
                    value: null,
                    isShow: null
                },
                {
                    name: '紧急联系人(选填):',
                    key: 'urgeName',
                    value: '',
                    isShow: null,
                },
                {
                    name: '紧急联系人电话(选填):',
                    key: 'urgePhone',
                    value: '',
                    isShow: null
                },
                {
                    name: '经办人姓名(选填):',
                    key: 'agentName',
                    value: '',
                    isShow: null
                },
                {
                    name: '经办人手机号(选填):',
                    key: 'agentPhone',
                    value: '',
                    isShow: null
                },
                {
                    name: '经办人身份证(选填):',
                    key: 'agentIdcard',
                    value: '',
                    isShow: null
                },
                // {
                //     name: '备用手机号(选填):',
                //     key: 'holderPhones',
                //     value: '',
                //     isShow: null
                // }
            ],
            initData: null,
            // 预存数据
            spareData: {
                id: null, // 增额所需ID
                state: 0, // 状态
            }
        }
    },
    computed: {
        // 打开所有验证提示
        isShowPromptCalc() {
            this.list.forEach((item, index) => {
                if ( Object.keys(item).indexOf("isPrompt") != -1 ) {
                    let newItem = item;
                    item.isPrompt = true;
                    this.list.splice(index, 1, newItem)
                }
            })
        },
        // 关闭所有验证提示
        isHidePromptCalc() {
            this.list.forEach((item, index) => {
                if ( Object.keys(item).indexOf("isPrompt") != -1 ) {
                    let newItem = item;
                    item.isPrompt = false;
                    this.list.splice(index, 1, newItem)
                }
            })
        }
    },
    mounted() {
        //bus.$emit(busType.IFRAME,'bglife://app');
    },
    beforeRouteEnter: (to, from, next) => {
        // 初始化数据
        next(vm => {vm.getInitData()});
    },
    methods: {
        // 初始化数据请求
        getInitData() {
            // 初始化请求
            this.$http(connectURL.INITMAST,{
                type: 'GET',
                params: {
                    userId: this.$route.query.userId
                }
            })
            .then(res => {
                // 是否为新建认证
                if( res.data.data === null ) {
                    this.isNewOrder = true;
                    return;
                }
                // 非新创建认证
                this.isNewOrder = false;
                
                // 错误
                if ( res.data.code != 0 ) {
                    this.$toast.show(res.data.message);
                    return;
                }

                // 返回初始化数据并设置数据
                let initData = res.data.data; 
                this.initData = initData;
                console.log( this.initData )

                // 本地数据循环添加接口返回数值
                this.list.forEach((item, index) => {
                    for(let i of Object.keys(initData)) {
                        if ( item.key === i ) {
                            // 设置本地数据value
                            item.value = initData[i];
                            // 通过value字段 设置isShow字段展现视图
                            if ( !item.value || this.initData.state == 0 || this.initData.state == 3) {
                                if (item.value === 0) {
                                    item.value = '';
                                }
                                item.isShow = false;
                            }else {
                                item.isShow = true;
                            }
                        }
                    }
                })

                // 预设所需参数
                this.spareData = {
                    id: initData.id,
                    state: initData.state
                };
                
            })
            .catch(err => {
                console.log( err )
                this.$toast.show(err.message);
            })
        },
        // 继续 创建或修改认证 跳转增额
        next() {
            let isNext = true;
            // 如有必选字段未选择，return掉
            console.log(this.list)
            // this.list.forEach((item, index) => {
            //     // if( !item.value && item.key != 'web' && item.key != 'holderPhones' ) {
            //     //     this.$toast.show(item.name.slice(0, item.name.length - 1) + '不能为空');
            //     //     isNext = false;
            //     //     return;
            //     // }
                
                
            // })
            
            
            if( !isNext ) return;

            // 验证通过后，如果是新创建认证，创建认证   待四要素接口发布后删除此代码块
            // this.isHidePromptCalc = false;
            // if ( this.isNewOrder ) {
            //     this.createOrder();
            // }else { // 验证通过后，如果是非新创建认证，更新认证
            //     this.changeOrder();
            // }

            
            // 在这里添加 等待四要素接口上线后增加此代码块 
            let params = {
                "name": '',
                "license": '',
                "holderName": '',
                "holderIdcard": '',
                "urgeName":'',
                "urgePhone":'',
                "agentName":'',
                "agentPhone":'',
                "agentIdcard":'',
                "userId": this.$route.query.userId
            }
            
            let result = [];
            this.list.forEach((item, index) => {
                Object.keys(params).forEach((subItem, subIndex) => {
                    if(item.key === subItem) {
                        params[item.key] = item.value
                    }
                })
            })

            // 中文正则
            let chinaReg = /^[\u4e00-\u9fa5]+$/;
            if ( params.holderIdcard.length != 18 ) { // 法人身份证不足18位
                this.$toast.show("法人身份证号需18位");
                return;
            }else if ( !chinaReg.test(params.holderName) ) { // 法人名称不为中文
                this.$toast.show("法人姓名必须为中文");
                return;
            }
            if ( params.urgeName!="") { // 紧急人姓名不为中文
            //alert(111111111)
                    if ( !chinaReg.test(params.urgeName) ){
                         this.$toast.show("紧急人姓名必须为中文");
                        return; 
                    }
                    if(params.urgeName!="" && params.urgePhone==""){
                        this.$toast.show("紧急联系人电话不能为空");
                        return;
                    }
            }
            if ( params.urgePhone!="") { // 紧急联系人电话不为中文
                    
                    if(params.urgePhone!="" && params.urgeName==""){
                        this.$toast.show("紧急联系人不能为空");
                        return;
                    }
            }
            if ( params.agentName!="") { // 经办人名称不为中文
                    if ( !chinaReg.test(params.agentName) ){
                         this.$toast.show("经办人姓名必须为中文");
                        return; 
                    }
                    if(params.agentName!="" && params.agentPhone==""){
                        this.$toast.show("经办人电话不能为空");
                        return;
                    }
                    if(params.agentName!="" && params.agentIdcard==""){
                        this.$toast.show("经办人身份证号不能为空");
                        return;
                    }
                    if(params.agentName!="" && params.agentIdcard.length != 18){
                        this.$toast.show("经办人身份证号需18位");
                        return;
                    }
            }

            if ( params.agentPhone!="") { // 经办人名称不为中文
                    if(params.agentPhone!="" && params.agentName==""){
                        this.$toast.show("经办人姓名不能为空");
                        return;
                    }
                    if(params.agentPhone!="" && !chinaReg.test(params.agentName) ){
                        this.$toast.show("经办人姓名必须为中文");
                        return;
                    }
                    if(params.agentPhone!="" && params.agentIdcard==""){
                        this.$toast.show("经办人身份证号不能为空");
                        return;
                    }
                    if(params.agentPhone!="" && params.agentIdcard.length != 18){
                        this.$toast.show("经办人身份证号需18位");
                        return;
                    }
            }
            if ( params.agentIdcard!="") { // 经办人名称不为中文
                    if(params.agentIdcard!="" && params.agentName==""){
                        this.$toast.show("经办人姓名不能为空");
                        return;
                    }
                    if(params.agentIdcard!="" && !chinaReg.test(params.agentName) ){
                        this.$toast.show("经办人姓名必须为中文");
                        return;
                    }
                    if(params.agentIdcard!="" && params.agentPhone==""){
                        this.$toast.show("经办人电话不能为空");
                        return;
                    }
            }
            this.isHidePromptCalc;
            // 验证通过后，如果是新创建认证，创建认证
            if ( this.isNewOrder ) {
                this.createOrder();
            }else { // 验证通过后，如果是非新创建认证，更新认证
                this.changeOrder();
            }
            // 四要素验证接口
            // this.$http(connectURL.ESSENTIAlFACTOR,{
            //     type: "POST",
            //     params
            // })
            // .then(res => {
            //     // if( res.data.code === -1 ) { // 四要素验证失败,返回数据为匹配失败项
            //     //     this.isShowDialog = true;
            //     //     this.isHidePromptCalc;

            //     //     res.data.data.forEach((item, index) => { // 返回数组为没有匹配成功的字段
            //     //         this.list.forEach((subItem, subIndex) => {
            //     //             if ( item === subItem.key ) {
            //     //                 let newItem = subItem;
            //     //                 subItem.isPrompt = true;
            //     //                 this.list.splice(subIndex, 1, newItem)
            //     //             }
            //     //         })
            //     //     })
            //     //     return;
            //     // }else if( res.data.code === -2 ) { // 系统繁忙,隐藏所有提示
            //     //     this.isHidePromptCalc;
            //     //     this.$toast.show('系统繁忙');
            //     //     return;
            //     // }else if( res.data.code === 60001 ) { // 没有查到相关信息,显示所有提示并弹层
            //     //     this.isShowDialog = true;
            //     //     this.isShowPromptCalc;
            //     //     return;
            //     // }else if( res.data.code === 60002 ) { // 验证超次,隐藏所有提示
            //     //     this.isHidePromptCalc;
            //     //     this.$toast.show('认证次数超限,24小时后尝试');
            //     //     return;
            //     // }else 
            //     //{ // 四要素验证成功,隐藏所有提示
            //         this.isHidePromptCalc;
            //         // 验证通过后，如果是新创建认证，创建认证
            //         if ( this.isNewOrder ) {
            //             this.createOrder();
            //         }else { // 验证通过后，如果是非新创建认证，更新认证
            //             this.changeOrder();
            //         }
            //     //}
            
            // })
            // .catch(err => {
            //     console.log( err )
            //     this.$toast.show(err.message);
            // })
            
        },
        // 创建新认证
        createOrder() { 
            let params = {
                "address": "",
                "holderIdcard": "",
                "holderName": "",
                "holderPhone": "",
                "holderPhones": "",
                "license": "",
                "name": "",
                "web": "",
                "urgeName": "",
                "urgePhone": "",
                "agentName": "",
                "agentPhone": "",
                "agentIdcard": "",
                "userId": this.$route.query.userId,
                "state": this.spareData.state
            }
            // 设置请求参数
            this.list.forEach((item, index) => {
                for(let i of Object.keys(params)){
                    if( item.key === i ) {
                        params[i] = item.value
                    }
                }
            })

            // 创建新基本认证
            this.$http(connectURL.SETMAST,{
                type: 'POST',
                params: params
            })
            .then(res => {
                console.log( res )
                if( res.data.code != 0 ) {
                this.$toast.show(res.data.message);  
                return;
                }
                this.$router.push(`/addauthentication?userId=${this.$route.query.userId}&id=${res.data.data.id}&state=${this.spareData.state}`);
            })
            .catch(err => {
                console.log( err.message )
                this.$toast.show(err.message);
            });
        },
        // 修改之前认证
        changeOrder() {
            let list = this.list;
            let initData = this.initData;

            // 请求参数
            let params = {
                id: this.spareData.id,
                state: this.spareData.state
            }
            // 遍历修改字段并设置参数 
            list.forEach((item, index) => {
                for( let i of Object.keys(initData) ) {
                    if ( item.key === i ) {
                        if ( item.value != initData[i] ) {
                            params[item.key] = item.value;
                        }
                    }
                }
            })
            console.log( '更新请求参数===>>', params )

            // 更新
            this.$http(connectURL.UPDATEMAST,{
                type: 'POST',
                params
            })
            .then(res => {
                // 失败
                if ( res.data.code != 0 ) {
                    this.$toast.show(res.data.message);  
                    return;
                }
                this.$router.push(`/addauthentication?userId=${this.$route.query.userId}&id=${params.id}&state=${params.state}`);
            })
            .catch(err => {
                console.log( err )
                this.$toast.show(err.message);
            });
        },
        // 点击查看认证信息
        handleShow( type ) {
            bus.$emit( busType.IFRAME, `zclease://app?action=3&data={"type":${type},"companyId":${this.initData.id}}`);
        },
        // 关闭dialog
        closeDialog() {
            this.isShowDialog = false;
        }
    }
}
</script>

<style lang="less" src="./index.less"></style>
