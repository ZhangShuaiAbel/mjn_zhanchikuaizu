<template>
   <div id="zckz" class="ok">
        <div class="zckz_logo"></div>
        <div class="button">
            <div @click="download()" class="img_btn"></div>
        </div>
        <div class="bg_alert" v-if="ifshow">
            <div id="wx_download"></div>
        </div>
    </div>
    
</template>

<script>
var android_download='https://mr.baidu.com/bb2b2qz';
var ios_download='https://itunes.apple.com/cn/app/id1364796775';
export default {
    name: 'zckz',
    data(){
        return {
            ifshow:false,
        }   
    },
    computed:{
        is_weixin() {
            var ua = navigator.userAgent.toLowerCase();
            if (ua.match(/MicroMessenger/i) == "micromessenger") {
                return true;
            } else {
                return false;
            }
        },
        is_ios(){
            var u = navigator.userAgent;
            var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); 
            return isiOS;
        },
    },
    methods: {
        download(){
            if(this.is_weixin){
                this.ifshow = true;
            }else{
                this.ifshow = false;
                if(this.is_ios){
                    window.location.href=ios_download;
                }else{
                    window.location.href=android_download;
                }
            }
        },       
    }
}
</script>

<style lang="less" src="./index.less"></style>