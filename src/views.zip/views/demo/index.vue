<template>
    <div class="home">
      <div class="home-content">
        <mc-swiper :autoplay="true" :loop="true"></mc-swiper>
      </div>
    </div>
</template>
<script>

import * as connectURL from "@/http/common/connectURL";
import * as mutationTypes from "@/vuex/mutations/types";
import * as actionTypes from "@/vuex/actions/types";
import { 
  mapState, 
  mapMutations
} from "vuex";

export default {
  name: "home",
  data() {
    return {
      msg: "我是组件计算属性"
    };
  },
  computed: {
    ...mapState(["count"])
  },
  mounted() {
    this.$http(connectURL.defaultGET)
    .then(res => {
      console.log( res )
    })
    .catch(err => {
      this.$toast.show(err.message);
    })
  },
  methods: {
    
  }
};
</script>

<style lang="less" src="./index.less"> </style>