<template>
    <div class="paysuccess">
        <div class="success-bgk"></div>
        <div class="success-font">实名认证成功</div>
        <div class="success-prompt">    
            <p>线上支付只能使用此实名认证信息进行支付</p>
            <p>如需变更请联系：4001810160</p>
        </div>
        <div class="btn" @click="payFun">前往支付</div>
    </div>
</template>

<script>
import {bus, busType} from '@/bus';
import * as connectURL from "@/http/common/connectURL";

export default {
    name: 'paysuccess',
    methods: {
        payFun(){
            if(this.$route.query.type == 1){
                var requestUrl = connectURL.PAYORDER;
                var paramsData = {orderId : this.$route.query.orderId}
            }else if(this.$route.query.type == 2){
                var requestUrl = connectURL.payBill;
                var paramsData = {billId : this.$route.query.billId}

            }
            this.$http(requestUrl,{
                type: 'GET',
                params:paramsData
            })
            .then(res => {
                console.log( res )
                //失败
                if ( res.data.code != 0 ) {
                    this.$toast.show(res.data.message);  
                    return;
                }                
                window.location.href=res.data.data;    
            })
            .catch(err => {
                console.log( err )
                this.$toast.show(err.message);
            });
        }
    }
}
</script>

<style lang="less" src="./index.less"></style>origin 