<template>
    <div class="paysuccess">
        <div class="success-bgk"></div>
        <div class="success-font">支付成功</div>
        <div class="success-prompt">支付状态若未及时更新请耐心等待几分钟</div>
        <div class="btn" @click="serviceFun">返回详情</div>
    </div>
</template>

<script>
import {bus, busType} from '@/bus';

export default {
    name: 'paysuccess',
    methods: {
        serviceFun(){
            let action = `zclease://app?action=2`;
            bus.$emit(busType.IFRAME, action);
        }
    }
}
</script>

<style lang="less" src="./index.less"></style>