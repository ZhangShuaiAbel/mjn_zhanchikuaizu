<template>
    <div class="coupon">
        <div class="coupon_img">
        </div>
        <p class="coupon_text">您暂时没有优惠券</p>
    </div>
</template>

<script>
export default {
    name: 'available'
}
</script>

<style lang="less" src="./index.less"></style>