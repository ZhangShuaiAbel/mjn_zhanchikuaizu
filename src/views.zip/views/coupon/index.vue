<template>
    <div class="available" ref="wrapper">
        <div class="header">
            <div class="available_wrap">
                <ul class="contents available_panel available_tab">
                    <router-link class="linkStyle" :to="getavailable" exact replace active-class="is_active">
                        <a class="is_active_color">可用优惠券</a>
                    </router-link>
                    <router-link class="linkStyle" :to="getNoavailable" exact replace active-class="is_active">
                        <a class="is_active_color">不可用优惠券</a>
                    </router-link> 
                </ul>
                <div class="details_panel_slider">
                    <p class="slider" :class="sliderActivClass"></p>
                </div>
            </div>
        </div>
            
         
            <!-- scroll start -->
            <div class="scroll_wrap" ref="scroll">
                  <transition :name="direction" mode="out-in">
                    <router-view></router-view>
                  </transition>
            </div>
            <!-- scroll end -->
    </div>
</template>

<script>
import * as connectURL from "@/http/common/connectURL";
import * as mutationTypes from "@/vuex//mutations/types";
import * as actionTypes from "@/vuex/actions/types";
import { bus, busType } from "@/bus";


export default {
  name: "popup",
    data() {
    return {
      direction: 'left',
      routerLinkPath: {
        available: '/coupon',
        Noavailable: '/coupon/Noavailable',
      }
    };
  },
   computed: {
    getavailable() {
      let path = `${this.routerLinkPath.available}`;
      return path;
    },
    getNoavailable() {
      let path = `${this.routerLinkPath.Noavailable}`;
      return path;
    },
    sliderActivClass() {
      
      if ( this.$route.meta.index === 1 ) {
        return 'location_1'
      }else if ( this.$route.meta.index === 2 ) {
        return 'location_2'
      }
    },


  },
  watch: {
    
    $route(to, from) {
      // 重新计算scroll
      //this.scroll.refresh();
      if ( to.meta.index > from.meta.index ) {
        this.direction = 'left'; 
      }else {
        this.direction = 'right';
      }
    }
  },

}
</script>

<style lang="less" src="./index.less" scoped></style>
