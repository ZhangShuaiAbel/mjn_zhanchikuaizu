<template>
    <div class="success_authentication">
        <div class="success_authentication_logo"></div>
        <div class="success_authentication_title">资料提交成功</div>
        <div class="success_authentication_desc">
            <span>审核人员将会于24小时内与您联系</span>
            <span>请保持通讯畅通</span>
        </div>

        <div class="success_authentication_step">
            <div class="success_authentication_step_item">
                <div class="success_authentication_step_item_icon"></div>
                <p class="success_authentication_step_item_text">提交资料</p>
            </div>
            <div class="success_authentication_step_item">
                <div class="success_authentication_step_item_icon"></div>
                <p class="success_authentication_step_item_text">资料审核</p>
            </div>
            <div class="success_authentication_step_item">
                <div class="success_authentication_step_item_icon"></div>
                <p class="success_authentication_step_item_text">减免押金</p>
            </div>
        </div>

        <div class="success_authentication_button" @click="handleBtn">返回</div>
    </div>
</template>

<script>
import {bus, busType} from '@/bus';
import * as connectURL from "@/http/common/connectURL";

export default {
    name: 'succesAauthentication',
    methods: {
        handleBtn() {
           let params = {
               userId: parseInt(this.$route.query.userId),
               id: parseInt(this.$route.query.id),
               state: 1 
           }
           // 更新状态
           this.$http(connectURL.UPDATEMAST,{
               type: 'POST',
               params
           })
           .then(res => {
               console.log( res )
               // 失败
               if( res.data.code != 0 ) {
                   this.$toast.show(res.data.message);
                   return;
               }
               let action = `zclease://app?action=2`;
               bus.$emit(busType.IFRAME, action);
           })
           .catch(err => {
               console.log( err )
               this.$toast.show(err.message);
           }) 
        }
    }
}
</script>

<style lang="less" src="./index.less"></style>